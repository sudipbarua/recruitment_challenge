import numpy as np
from duopoly import p
from typing import Dict, Any

def run_simulation(num_seasons: int, periods_per_season: int):
    """
    Simulates a pricing environment to test the p(...) function.
    
    This function generates mock historical data and calls the p(...)
    function to observe the state evolution and price predictions.
    
    Parameters
    ----------
    num_seasons : int
        The number of selling seasons to simulate.
    periods_per_season : int
        The number of selling periods in each season.
    """
    print("--- Starting Price Optimization Simulation ---")

    # This dictionary will act as our historical data store
    # It stores the full history to pass to the p function, as per the function signature.
    historical_data: Dict[str, Any] = {
        'my_prices': [],
        'comp_prices': [],
        'demand': []
    }

    # information_dump is the key state variable that p(...) modifies and returns
    information_dump = None

    for season in range(1, num_seasons + 1):
        print(f"\n======== Season {season} ========")
        
        # Reset data for a new season
        historical_data = {
            'my_prices': [],
            'comp_prices': [],
            'demand': []
        }
        information_dump = None
        
        for period in range(1, periods_per_season + 1):
            
            # --- Mock Data Generation ---
            # Simulate a competitor price with a slight upward trend
            comp_price = 50 + 0.1 * period + np.random.normal(0, 2)
            
            # Use a price from the previous period if available, otherwise a random one
            if historical_data['my_prices']:
                last_my_price = historical_data['my_prices'][-1]
            else:
                last_my_price = np.random.uniform(30, 70)

            # --- Call the Optimizer ---
            # Pass the historical data up to the previous period to p(...)
            historical_prices_np = np.array([historical_data['my_prices'], historical_data['comp_prices']]) if historical_data['my_prices'] else None
            historical_demand_np = np.array(historical_data['demand']) if historical_data['demand'] else None

            new_price, information_dump = p(
                current_selling_season=season,
                selling_period_in_current_season=period,
                prices_historical_in_current_season=historical_prices_np,
                demand_historical_in_current_season=historical_demand_np,
                competitor_has_capacity_current_period_in_current_season=True,
                information_dump=information_dump
            )
            
            # Simulate demand based on the new price (for the next period's data)
            # Use a simple mock demand model: Demand = 150 - 1.5 * my_price + 0.5 * comp_price
            simulated_demand = 150 - 1.5 * new_price + 0.5 * comp_price + np.random.normal(0, 5)
            
            # Append the new data to our historical data store
            historical_data['my_prices'].append(new_price)
            historical_data['comp_prices'].append(comp_price)
            historical_data['demand'].append(max(0, simulated_demand)) # Ensure demand is not negative

            # Display the current state for monitoring
            print(f"  > Period {period} State:")
            print(f"    - My Price: {new_price:.2f}")
            print(f"    - Comp Price: {comp_price:.2f}")
            print(f"    - My Demand: {simulated_demand:.2f}")
            if information_dump:
                print(f"    - Cumulative Revenue: {information_dump.get('revenue', 0):.2f}")
            print("-" * 20)
            
    print("--- Simulation Complete ---")

if __name__ == "__main__":
    run_simulation(num_seasons=2, periods_per_season=20)
