import numpy as np
from typing import Tuple, Any, Union


# Add a regularization parameter to stabilize the model coefficients (Ridge Regression)
# Too large --> model is too biased (regularized); too small --> may be unstable
RIDGE_LAMBDA = 10.0


def online_wls_update(XTX, XTy, prices, mean_comp_price, std_dev_comp_price, MAX_PRICE):
    try:
        # Add Ridge regularization to the diagonal of XTX to stabilize the inversion
        XTX_reg = XTX + RIDGE_LAMBDA * np.eye(3)
        # Solve the linear system XTX * beta = XTy to get the coefficients
        # This is a constant-time operation with respect to the number of samples.
        coefficients = np.linalg.solve(XTX_reg, XTy)
        alpha, beta_self, beta_comp = coefficients[0], coefficients[1], coefficients[2]

        # Check for a sensible coefficient for price sensitivity
        if beta_self <= 1e-6: # Check if beta_self is effectively zero or negative
            # If beta_self is non-positive, the revenue function is not concave down.
            # in this case we use the histroy averaging strategy to predict the price
            price = mean_comp_price + 0.1 * std_dev_comp_price
            print(" \t Algo: Unstable model (beta_self <= 0). Reverting to competitors history averaging: %.2f" % price)
        else:
            # The predicted optimal price is derived from maximizing the revenue function.
            # Revenue(P) = P * Demand = P * (α - β_self*P + β_comp*P_comp)
            # The maximum occurs at the vertex of this parabola.
            predicted_comp_price = prices[1, -1]
            price = (alpha + beta_comp * predicted_comp_price) / (2 * beta_self)
            
            # Add a check to prevent overshooting to unrealistic values
            if price > MAX_PRICE:
                price = MAX_PRICE
                print(" \t Algo: Price capped at MAX_PRICE: %.2f" % price)

            print(" \t Algo: New optimal price is: %.2f" % price)

    except np.linalg.LinAlgError:
        # Fallback in case of a singular matrix (e.g., all prices are the same)
        price = prices[0, -1]
        print(" \t Algo: Warning: Matrix is singular. Keeping old price: %.2f" % price)
    return price


def p(
    current_selling_season: int,
    selling_period_in_current_season: int,
    prices_historical_in_current_season: Union[np.ndarray, None],
    demand_historical_in_current_season: Union[np.ndarray, None],
    competitor_has_capacity_current_period_in_current_season: bool,
    information_dump: Any,
) -> Tuple[float, Any]:
    """
    Determines the optimal price to set for the next period using an O(1)
    incremental Weighted Least Squares (WLS) approach for a demand model.

    The model is: Demand = α - β_self * Price_self + β_comp * Price_comp.
    This function updates the model's summary statistics incrementally,
    and then calculates the revenue-maximizing price based on the current
    estimated coefficients.
    
    The state (the summary statistics) is stored and passed through the `information_dump`.
    
    Parameters
    ----------
    current_selling_season : int
        The current selling season (1, 2, 3, ...).
    selling_period_in_current_season : int
        The period in the current season (1, 2, ..., 1000).
    prices_historical_in_current_season : Union[np.ndarray, None]
        A two-dimensional array of historical prices. The rows index the competitors and the columns
        index the historical selling periods. Equal to `None` if`selling_period_in_current_season == 1`.
    demand_historical_in_current_season : Union[np.ndarray, None]
        A one-dimensional array of historical (own) demand. Equal to `None` if `selling_period_in_current_season == 1`.
    competitor_has_capacity_current_period_in_current_season : bool
        `False` if competitor is out of stock
    information_dump : Any, optional
        To keep a state (e.g., a trained model), by default None

    Returns
    -------
    Tuple[float, Any]
        The price and the updated information dump (with, e.g., a state of the model).
    """
    # first set some shorter names for convenience
    day = selling_period_in_current_season
    season = current_selling_season
    demand = demand_historical_in_current_season
    prices = prices_historical_in_current_season
    
    # Setting up a price cap for 
    MAX_PRICE = max(prices[1, :]) if prices is not None else 70.0

    # set some indicator variables
    first_day = True if day == 1 else False

    print(' \t Algo: ---')
    print(" \t Algo: we are in selling_season %d and selling_period %d" % (season, day))
    
    # Our information dump will store the summary statistics for the online model
    # (XTX and XTy matrices) and the number of samples.
    if first_day:
        # Initialize the model's state for the new season
        # The X^T*X matrix from the normal equations, for 3 parameters: alpha, beta_self, beta_comp.
        XTX = np.zeros((3, 3))
        # The X^T*y vector.
        XTy = np.zeros(3)
        # The number of data points.
        n_samples = 0
        
        information_dump = {
            'revenue': 0,
            'XTX': XTX,
            'XTy': XTy,
            'competitor_price_history_mean': 0.0,
            'competitor_price_history_std_dev': 0.0,
            'n_samples': n_samples
        }
        
        # In the first period, we set a random price to gather initial data.
        price = np.random.uniform(30, 70)
        print(" \t Algo: setting random price at init: %.3f" % price)

    elif selling_period_in_current_season == 101:
        # No price in selling period 101 (only used for getting information from previous period)
        price = None
    elif not competitor_has_capacity_current_period_in_current_season:
        print(" \t Algo: Competitor is out of stock: ")
        # Exploit the benefit of being a monopolist
        price = MAX_PRICE    
    else:
        # Retrieve the current state from the information dump
        XTX = information_dump['XTX']
        XTy = information_dump['XTy']
        n_samples = information_dump['n_samples']
        mean_comp_price = information_dump['competitor_price_history_mean']
        std_dev_comp_price = information_dump['competitor_price_history_std_dev']

        # Get the latest data point from the historical arrays
        # prices[0, -1] is our last price, prices[1, -1] is the competitor's last price
        my_price_last_period = prices[0, -1]
        comp_price_last_period = prices[1, -1]
        demand_last_period = demand[-1]

        # Construct the feature vector for the latest observation.
        # The terms correspond to: [intercept, -my_price, comp_price]
        x_vector = np.array([1, -my_price_last_period, comp_price_last_period])
        y_scalar = demand_last_period

        # Perform the incremental, O(1) updates to the summary statistics.
        # This avoids re-fitting the entire model from scratch.
        XTX += np.outer(x_vector, x_vector)
        XTy += x_vector * y_scalar
        n_samples += 1

        # Update the competitor price history statistics
        # mean_comp_price = (mean_comp_price + comp_price_last_period) / 2 if n_samples > 1 else comp_price_last_period
        mean_comp_price = np.mean(prices[1, :]) 
        std_dev_comp_price = np.std(prices[1, :]) 
        information_dump['competitor_price_history_mean'] = mean_comp_price
        information_dump['competitor_price_history_std_dev'] = std_dev_comp_price

        # Store the updated state back in the information dump.
        information_dump['XTX'] = XTX
        information_dump['XTy'] = XTy
        information_dump['n_samples'] = n_samples

        # Now, predict the optimal price for the next period.
        # We need at least 3 data points to solve for our 3 parameters.
        if n_samples < 3:
            price = np.random.uniform(30, 70)
            print(" \t Algo: Not enough data for model. Setting random price: %.2f" % price)
        else:
            price = online_wls_update(XTX, XTy, prices, mean_comp_price, std_dev_comp_price, MAX_PRICE)
        print(" \t Algo: my last price is: %.2f" % my_price_last_period)
        print(" \t Algo: competitor last price is: %.2f" % comp_price_last_period)

    # Update the information dump with the new revenue data.
    if not first_day and prices is not None:
        revenue_last_period = demand[-1] * prices[0, -1]
        information_dump['revenue'] = information_dump.get('revenue', 0) + revenue_last_period
    
    return price, information_dump
