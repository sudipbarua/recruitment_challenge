import unittest
import numpy as np
from duopoly import p

class TestInformationDumpTransfer(unittest.TestCase):
    def test_information_dump_transfer(self):
        
        
        
        """
        Test case to verify that the information dump correctly transfers state.
        """
        print("--- Running test_information_dump_transfer ---")

        # --- Step 1: Simulate the first day of a season ---
        print("\nSimulating Day 1: Initialization")
        season = 1
        day1_price, information_dump_day1 = p(
            current_selling_season=season,
            selling_period_in_current_season=1,
            prices_historical_in_current_season=None,
            demand_historical_in_current_season=None,
            competitor_has_capacity_current_period_in_current_season=True,
            information_dump=None
        )

        # Verify initial state
        assert information_dump_day1['n_samples'] == 0, "Initial n_samples should be 0"
        assert np.all(information_dump_day1['XTX'] == np.zeros((3, 3))), "Initial XTX should be all zeros"
        assert np.all(information_dump_day1['XTy'] == np.zeros(3)), "Initial XTy should be all zeros"
        print("Assertions for Day 1 passed. Initial state is correct.")

        # --- Step 2: Simulate the second day, passing the information dump from day 1 ---
        print("\nSimulating Day 2: Data Transfer and Update")
        # Dummy historical data for Day 2 (including data from Day 1)
        # The last element in each array is the data from the previous period (Day 1)
        historical_prices_day2 = np.array([
            [day1_price],    # My price from Day 1
            [50.0]           # Competitor's dummy price from Day 1
        ])
        historical_demand_day2 = np.array([100.0]) # My dummy demand from Day 1

        day2_price, information_dump_day2 = p(
            current_selling_season=season,
            selling_period_in_current_season=2,
            prices_historical_in_current_season=historical_prices_day2,
            demand_historical_in_current_season=historical_demand_day2,
            competitor_has_capacity_current_period_in_current_season=True,
            information_dump=information_dump_day1
        )

        # Verify that the state was correctly updated
        assert information_dump_day2['n_samples'] == 1, "n_samples should be 1 after one update"
        assert not np.all(information_dump_day2['XTX'] == np.zeros((3, 3))), "XTX should be updated and not all zeros"
        assert not np.all(information_dump_day2['XTy'] == np.zeros(3)), "XTy should be updated and not all zeros"
        print("Assertions for Day 2 passed. State variables have been correctly updated.")

        print("\n--- Test finished successfully! The information dump is working as expected. ---")

    def test_incremental_update_equivalence(self):

        # 1. Define a sample data history
        test_prices = np.array([
            [69.7, 68.6, 67.1, 65.5, 63.8, 63.8, 62.5, 60.7, 58.4, 55.8, 55.8, 53.6, 53.6, 51.3, 49.1, 46.5, 46.5, 46.5, 45.0, 45.0, 45.4, 45.8, 45.8, 45.8, 46.3, 47.2, 48.2, 50.4, 53.3, 56.5, 60.7, 60.7, 60.7, 65.8, 71.6, 71.6, 71.6, 71.6, 71.6, 71.6], # My historical prices
            [39.2, 39.5, 49.1, 65.1, 73.3, 75.2, 40.6, 64.8, 62.3, 75.2, 69.0, 51.0, 38.0, 35.0, 53.0, 66.0, 60.0, 48.0, 48.0, 73.0, 28.0, 28.0, 46.0, 56.0, 56.0, 81.0, 73.0, 41.0, 41.0, 78.0, 59.0, 59.0, 55.0, 62.0, 26.0, 26.0, 59.0, 40.0, 41.0, 39.0]  # Competitor historical prices
        ])
        test_demand = np.array([0, 0, 1, 1, 2, 1, 0, 0, 0, 2, 1, 2, 0, 1, 0, 3, 3, 0, 3, 4, 1, 0, 1, 2, 2, 1, 3, 2, 1, 2, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0]) # Historical demand

        # 2. Simulate the incremental process using the 'p' function
        info_dump = None

        print("\n--- Running Test: test_incremental_update_equivalence ---")
        
        for i in range(1, test_prices.shape[1] + 1):
            if i <= 1:
                # On the first day, there's no history
                history_prices = None
                history_demand = None
            else:            
                # The 'p' function takes the last period's data to update its state
                # We must simulate a full history for each call
                history_prices = test_prices[:, :i]
                history_demand = test_demand[:i]
            
            # The function returns a price and the updated information dump
            next_price, info_dump = p(
                current_selling_season=1,
                selling_period_in_current_season=i,
                prices_historical_in_current_season=history_prices,
                demand_historical_in_current_season=history_demand,
                competitor_has_capacity_current_period_in_current_season=True,
                information_dump=info_dump
            )

            std_dev_comp_price_algo = info_dump['competitor_price_history_std_dev']
            mean_comp_price_algo = info_dump['competitor_price_history_mean']

            measured_std_dev = np.std(test_prices[1, :i]) # if i >= 1 else 0.0

            # assert std_dev_comp_price_algo == measured_std_dev, f"Std dev mismatch at step {i}: {std_dev_comp_price_algo} vs {measured_std_dev}"
            if i > 3:
                measured_mean = np.mean(test_prices[1, :i]) 
                assert mean_comp_price_algo == measured_mean, f'Mean mismatch at step {i}: {mean_comp_price_algo} vs {measured_mean}'
                assert std_dev_comp_price_algo == measured_std_dev, f"Std dev mismatch at step {i}: {std_dev_comp_price_algo} vs {measured_std_dev}"

                print("\n--- Test successfull! mean and standard deviation . ---")


if __name__ == "__main__":
    unittest.main(argv=['first-arg-is-ignored'], exit=False)